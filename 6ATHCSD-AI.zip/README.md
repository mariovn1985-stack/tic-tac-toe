# Tic Tac Toe - 6ATHCSD (AI: cực khó)

Trang này chứa game Tic Tac Toe với AI sử dụng thuật toán Minimax (khó, gần như không thua).

## Hướng dẫn nhanh
1. Upload thư mục `6ATHCSD-AI` vào repository GitHub (hoặc copy các file vào repo).
2. Trong repo, bật **Settings → Pages**:
   - Source: `main` branch
   - Folder: `/ (root)`
3. Tạo file `CNAME` (đã có sẵn trong zip) chứa `6ATHCSD.cf`.
4. Trỏ DNS của domain `6ATHCSD.cf`:
   - Thêm bản ghi A: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - Thêm CNAME cho `www` trỏ tới `your-username.github.io`
5. Chờ vài phút để DNS cập nhật rồi truy cập `https://6ATHCSD.cf`.

-- File trong gói --
- index.html : game + AI
- README.md  : hướng dẫn
- CNAME      : chứa tên miền `6ATHCSD.cf`
